# -*- encoding=utf8 -*-
__author__ = "yewen"
# import airtest/poco
from airtest.core.api import *
from poco.drivers.unity3d import UnityPoco
auto_setup(__file__)
# connect_device("Android:///606cc8b9?cap_method=JAVACAP&&ori_method=ADBORI")

wake()
stop_app("com.xlycs.rastar")
start_app("com.xlycs.rastar")

wait(Template(r"tpl1553754458623.png", record_pos=(-0.429, -0.87), resolution=(1080, 2244)))

# 初始化UnityPoco
poco = UnityPoco(addr=('localhost', 5001), unity_editor=False, connect_default_device=True, device=None, action_interval = 0.8)

# 等待公告
poco("ImgBackground").wait()
# 关闭公告
poco("ImgBackground").click([0.5, 0.1], 0.1)
poco("BtnStart").attr("visible")
# 等待热更新结束
poco("BtnStart").wait()
# 进入游戏 TODO加载完成
poco("ImgBackground1").click()

# 如果出现起名界面
if poco("InputField").exists():
    # 起名后确定
    poco("InputField").set_text("Test")
    poco("Button").click()
    poco("怒气值满_按钮效果_闪烁_底部流动")

# 等待进入主线按钮出现后点击
wait(Template(r"tpl1553755546891.png", record_pos=(0.383, 0.855), resolution=(1080, 2244)))
poco("TestBattle").wait()
poco("TestBattle").click()\

def enter_last_map_node():
    index = 0
    nodePoco = poco("MapBg_0").child("MapNode_"+str(index))
    lastNodePoco = nodePoco
    while nodePoco.child("Bottom").exists():
        index += 1
        lastNodePoco = nodePoco
        nodePoco = poco("MapBg_0").child("MapNode_"+str(index))
    lastNodePoco.click()
    return index
    
def battle_test():
    poco("BattleView").wait()
    while not poco("BattleResultView").exists():
        if poco("NewBirdGuide").exists():
            poco("NewBirdGuide").child("bg").click()
        elif poco("2Speed", type="Button").exists():
            pos = poco("2Speed", type="Button").get_position()
            if (0 <= pos[0] <= 1) and (0 <= pos[1] <= 1):
                poco("2Speed", type="Button").click()

        print(poco.agent.get_debug_profiling_data())
        time.sleep(5)
        
    defeatView = poco("UIDefeatCase")
    vitoryView = poco("UIVitoryCase")
    endView = poco.wait_for_any([defeatView, vitoryView])
    wait(Template(r"tpl1553762333772.png", record_pos=(0.001, 0.947), resolution=(1080, 2244)))
    endView.child("ButtonConfirm").click()

while not poco("ClickNextChapter").exists():        
    poco("MapBg_0").wait()
    # 进入最新的节点
    index = enter_last_map_node()
    time.sleep(2)
    if poco("UIPreBattle").exists():# 战斗流程
        poco("BtnMid").click()
        battle_test()
    else:# 剧情流程
        poco("SceneWindow").wait()
        w, h = device().get_current_resolution()
        while not poco("MapBg_0").exists():
            print(poco.agent.get_debug_profiling_data())
            if poco("MsgPanel").exists() or poco("TailorView").exists() or poco("ClothingView").exists():
                poco("ClothingGray").click()
            elif poco("Choice").exists():
                poco("Choice").child("Button_1").click()
            elif poco("UISoundCall").exists():
                poco("BtnConfirm").click()
            else:
                device().touch([0.5 * w, 0.5 * h])
                device().touch([0.5 * w, 0.5 * h])
                device().touch([0.5 * w, 0.5 * h])
                device().touch([0.5 * w, 0.5 * h])
                device().touch([0.5 * w, 0.5 * h])
                device().touch([0.5 * w, 0.5 * h])
                time.sleep(0.5)


poco("ClickNextChapter").click()
print("===========Test Over!=============")


